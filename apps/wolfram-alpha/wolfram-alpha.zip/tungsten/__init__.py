"""
tungsten
~~~~~~~~

Main module

"""

from .core import *

__title__ = 'tungsten'
__version__ = '0.1.1'
__author__ = 'Seena Burns'
__license__ = 'BSD'
__copyright__ = 'Copyright 2012 Seena Burns'
