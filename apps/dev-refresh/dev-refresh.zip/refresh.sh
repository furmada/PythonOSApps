cd /home/pi/
sudo xkill -a
sudo sh /home/pi/refresh.sh
cd pyos
sudo startx
