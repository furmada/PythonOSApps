cd /home/pi/
sudo killall python
sudo xkill -a
sudo sh /home/pi/reload.sh
cd pyos
sudo startx
