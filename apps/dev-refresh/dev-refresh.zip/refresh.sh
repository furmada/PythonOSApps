cd /home/pi/
xkill -a
sh /home/pi/refresh.sh
cd pyos
startx
